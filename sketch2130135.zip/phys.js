function runPhys(repeats, g) {
	for (var r = 0; r < repeats; r++) {
		let xo = -p.x + 128
		let yo = -p.y + 96
		let sides = [];
		for (var x = -1; x < 9; x++) {
			for (var y = -1; y < 7; y++) {
				let i = (floor(x) - floor(xo / 32))
				let j = (floor(y) - floor(yo / 32))
				if (xo < 0) {
					i--;
				}
				if (yo < 0) {
					j--;
				}
				let id = getLevel(i, j)
				if (id == 2) {
					if (x > 1 && y > 0 && x < 6 && y < 5) {
						sides.push([x * 32 + 1 + xo % 32, y * 32 + yo % 32, x * 32 + 31 + xo % 32, y * 32 + yo % 32, 0]);
						sides.push([x * 32 + 32 + xo % 32, y * 32 + 1 + yo % 32, x * 32 + 32 + xo % 32, y * 32 + 31 + yo % 32, 1]);
						sides.push([x * 32 + 32 + xo % 32, y * 32 + 32 + yo % 32, x * 32 + 1 + xo % 32, y * 32 + 32 + yo % 32, 2]);
						sides.push([x * 32 + xo % 32, y * 32 + 31 + yo % 32, x * 32 + xo % 32, y * 32 + 1 + yo % 32, 3]);
					}
				}
			}
		}
		let rot = -p.bodyVec.heading()
		let playerPoints = [];
		playerPoints[0] = [128 + sin(rot + PI / 3.3) * 19, 96 + cos(rot + PI / 3.3) * 19]
		playerPoints[1] = [128 + sin(rot - PI / 3.3) * 19, 96 + cos(rot - PI / 3.3) * 19]
		playerPoints[2] = [128 + sin(rot + PI / 3.3) * -19, 96 + cos(rot + PI / 3.3) * -19]
		playerPoints[3] = [128 + sin(rot - PI / 3.3) * -19, 96 + cos(rot - PI / 3.3) * -19]
		playerPoly = [
			createVector(playerPoints[0][0], playerPoints[0][1]),
			createVector(playerPoints[1][0], playerPoints[1][1]),
			createVector(playerPoints[2][0], playerPoints[2][1]),
			createVector(playerPoints[3][0], playerPoints[3][1])
		]

		for (var i = 0; i < sides.length; i++) {
			if (collideLinePoly(sides[i][0], sides[i][1], sides[i][2], sides[i][3], playerPoly)) {
				side = sides[i][4];
				if (side === 0) {
					p.y -= g;
					p.moveVec.y = 0;
				}
				if (side == 1) {
					p.x += g;
					p.moveVec.x = 0;
				}
				if (side == 2) {
					p.y += g;
					p.moveVec.y = 0;
				}
				if (side == 3) {
					p.x -= g;
					p.moveVec.x = 0;
				}
			}
		}
	}
}

function playerPhys(tempMoveVec) {
	tempMoveVec.normalize();
	p.moveVec.add(tempMoveVec.mult(0.6))
	p.x += p.moveVec.x
	p.y += p.moveVec.y
	p.moveVec = p.moveVec.mult(0.7)
	p.bodyVec.add(tempMoveVec.mult(0.24))
	p.bodyVec.normalize();
	let mouseVec = createVector(0, 0);
	mouseVec.x = mouseX - 128 * s
	mouseVec.y = mouseY - 96 * s
	mouseVec.normalize();
	p.headVec.add(mouseVec.mult(0.3))
	p.headVec.normalize();
	p.bodyAnm += p.moveVec.mag() * 0.8;
	p.bodyAnm %= 4;
}