var tankAnm = [];
var tankHeadAnm = [];
var grass;
var grassTop;
var dirt;
var wall;
var mossyWall;
var s;
var tankSheet;
var keys = [];
var tankSound;
var fireSound;
var bulletImg;
var bullets = [];
var shadowLayer;
var lowIcon;
var highIcon;
var quality = true;
var slowFrames = 0;
var debris = [];
var debriImgs = [];
var worldMap;

p5.disableFriendlyErrors = true; //proformace speed up

var p = {
	x: -32,
	y: -32.01,
	moveVec: null,
	bodyVec: null,
	headVec: null,
	bodyAnm: 0,
	fireAnm: 0
};



function preload() {
	tankSheet = loadImage("tankSheetB.png");
	grass = loadImage("grass.png");
	grassTop = loadImage("grassTop.png");
	dirt = loadImage("dirtB.png");
	wall = loadImage("wall.png");
	mossyWall = loadImage("mossyWall.png");
	bulletImg = loadImage("bullet.png");
	tankSound = loadSound("tankSoundB.mp3");
	fireSound = loadSound("tankFire.wav");
	lowIcon = loadImage("low.png");
	highIcon = loadImage("high.png");
	debriImgs[0] = loadImage("dibri0.png");
	debriImgs[1] = loadImage("dibri1.png");
	debriImgs[2] = loadImage("dibri2.png");
	debriImgs[3] = loadImage("dibri3.png");
	debriImgs[4] = loadImage("dibri4.png");
	debriImgs[5] = loadImage("dibri5.png");
	debriImgs[6] = loadImage("dibri6.png");
	debriImgs[7] = loadImage("dibri7.png");
}



function setup() {
	s = min(windowWidth / 256, windowHeight / 192);
	createCanvas(256 * s, 192 * s);
	tankAnm[0] = tankSheet.get(0, 0, 40, 40)
	tankAnm[1] = tankSheet.get(0, 40, 40, 40)
	tankAnm[2] = tankSheet.get(0, 80, 40, 40)
	tankAnm[3] = tankSheet.get(0, 120, 40, 40)
	tankHeadAnm[0] = tankSheet.get(0, 160, 40, 40)
	tankHeadAnm[1] = tankSheet.get(0, 200, 40, 40)
	tankHeadAnm[2] = tankSheet.get(0, 240, 40, 40)
	tankHeadAnm[3] = tankSheet.get(0, 280, 40, 40)
	tankHeadAnm[4] = tankSheet.get(0, 320, 40, 40)
	tankHeadAnm[5] = tankSheet.get(0, 360, 40, 40)
	p.moveVec = createVector(0, 0)
	p.bodyVec = createVector(0.5, 0.501)
	p.headVec = createVector(0.5, 0.501)
	shadowLayer = createGraphics(255, 192)
	worldMap = createGraphics(50, 50);
	for (var x = 0; x < 50; x++) {
		for (var y = 0; y < 50; y++) {
			if (level[y][x] === 0) {
				worldMap.stroke(0, 255, 0);
			} else if (level[y][x] == 1) {
				worldMap.stroke(140, 120, 80);
			} else if (level[y][x] == 2) {
				worldMap.stroke(100, 100, 100);
			}
			worldMap.point(x, y)
		}
	}
}



function draw() {
	frameRate(30);
	background(100);
	noSmooth();

	control();

	drawGround(-p.x * s + 128 * s, -p.y * s + 96 * s);
	if (quality) {
		drawGrassTop(-p.x * s + 128 * s, -p.y * s + 96 * s);
		bodyShadow();
		headShadow();
		drawShadowsLayer();
	}
	drawTank(p.bodyVec.heading() + PI / 2);
	drawBullets(bullets);
	drawTankHead(p.headVec.heading() + PI / 2);
	drawWalls(-p.x * s + 128 * s, -p.y * s + 96 * s);
	drawDebris(debris);
	qualityIcon();
	if (quality) {
		runPhys(15, 0.1);
	} else {
		runPhys(5, 0.2);
	}
	sixtySec();
}