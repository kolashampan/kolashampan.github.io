function sixtySec() {
	if (frameCount > 30 * 20) {
		image(worldMap, 0, 0, 50 * s / 1.5, 50 * s / 1.5);
		noStroke();
		fill(255, 0, 0);
		let m = s / 32 / 1.5
		rect((p.x) * m - 1, (p.y) * m - 1, s * 1.5 / 2, s * 1.5 / 2);
	}
	if (frameCount % 30 === 0) {
		for (var x = 0; x < 50; x++) {
			for (var y = 0; y < 50; y++) {
				if (level[y][x] === 0) {
					worldMap.stroke(0, 255, 0);
				} else if (level[y][x] == 1) {
					worldMap.stroke(140, 120, 80);
				} else if (level[y][x] == 2) {
					worldMap.stroke(100, 100, 100);
				}
				worldMap.point(x, y)
			}
		}
	}
	if (frameCount > 30 * 10 && frameCount < 30 * 13) {
		textAlign(CENTER, CENTER)
		fill(0)
		noStroke()
		textSize(12 * s)
		text("You can now use your turret", 128 * s, 96 * s)
	}
}