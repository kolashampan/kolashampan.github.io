function bullet() {
	this.r = p.headVec.heading();
	this.x = p.x + cos(this.r) * 9
	this.y = p.y + sin(this.r) * 9
	this.l = 0;
}

function drawBullets(bullets) {
	shadowLayer.noStroke();
	shadowLayer.fill(0)
	for (var i = 0; i < bullets.length; i++) {
		bullets[i].l += 1;
		bullets[i].x += cos(bullets[i].r) * 10
		bullets[i].y += sin(bullets[i].r) * 10
		let xl = floor(bullets[i].x / 32)
		let yl = floor(bullets[i].y / 32)
		if (getLevel(xl, yl) == 2) {
			setLevel(xl, yl, 1)
			let count;
			if (quality) {
				count = random(4, 8);
			} else {
				count = 4;
			}
			for (var j = 0; j < count; j++) {
				debris.push(new debri(xl * 32 + 16, yl * 32 + 16, 2));
			}
			bullets.splice(i, 1)
		} else {
			push()
			imageMode(CENTER)
			translate(bullets[i].x * s - p.x * s + 128 * s, bullets[i].y * s - p.y * s + 96 * s)
			rotate(bullets[i].r + PI / 2);
			image(bulletImg, 0, 0, 2 * s, 3 * s);
			pop()
			if (quality && frameCount % 3 !== 0) { //every second frame get shadow with high quality grapics
				shadowLayer.push()
				shadowLayer.translate(bullets[i].x - p.x + 128, bullets[i].y - p.y + 96)
				shadowLayer.ellipse(1, 4, 4, 4)
				shadowLayer.pop()
			}
			if (bullets[i].l > 22) {
				bullets.splice(i, 1)
			}
		}
	}
}

function debri(x, y, z) {
	this.t = floor(random(0, 7.9999))
	this.r = random(0, 2 * PI)
	this.x = x
	this.y = y
	this.z = z
	this.xs = random(-3, 3);
	this.ys = random(-3, 3);
	this.zs = random(25, 45);
	this.rs = random(-0.5, 0.5)
}

function drawDebris(debris) {
	shadowLayer.noStroke();
	shadowLayer.fill(0)
	fill(100)
	for (var i = 0; i < debris.length; i++) {
		debris[i].x += debris[i].xs;
		debris[i].y += debris[i].ys;
		debris[i].z += debris[i].zs;
		debris[i].zs -= 1.1;
		debris[i].xs *= 0.98;
		debris[i].ys *= 0.98;
		debris[i].zs *= 0.98;
		debris[i].rs *= 0.95;
		push()
		imageMode(CENTER)
		translate(debris[i].x * s - p.x * s + 128 * s, (debris[i].y * s - p.y * s + 96 * s) - debris[i].z)
		if(quality) {
			rotate(debris[i].r);
		}
		debris[i].r += debris[i].rs
		if (quality) {
			image(debriImgs[debris[i].t], 0, 0, 12 * s, 12 * s)
		} else {
			fill(110, 120, 120)
			ellipse(0, 0, 8 * s, 8 * s);
			fill(60, 60, 75)
			ellipse(s, s, 7 * s, 7 * s);
		}
		pop()
		if (quality) { //every second frame get shadow with high quality grapics
			shadowLayer.push()
			shadowLayer.translate(debris[i].x - p.x + 128, debris[i].y - p.y + 96)
			shadowLayer.ellipse(0, 0, 4, 4)
			shadowLayer.pop()
		}
		if (debris[i].z < 0) {
			debris.splice(i, 1)
		}
	}
}