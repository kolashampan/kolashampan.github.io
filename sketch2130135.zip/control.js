function control() {
	let tempMoveVec = input();
	playerPhys(tempMoveVec);
	tankSound.setVolume(p.moveVec.mag() * 0.1 + 0.1)
	if (p.fireAnm > 0) {
		p.fireAnm++;
	}
	if (p.fireAnm > 5) {
		p.fireAnm = 0;
	}
	autoQuality();
}

function keyPressed() {
	tankSound.play()
	tankSound.loop()
	tankSound.setVolume(0)
	keys[keyCode] = true;
}

function keyReleased() {
	keys[keyCode] = false;
}

function mousePressed() {
	if (mouseX >= (255 - lowIcon.width / 2) * s && mouseY >= (191 - lowIcon.height / 2) * s) {
		quality = !quality;
	} else {
		if (p.fireAnm === 0 && frameCount > 30 * 10) {
			p.fireAnm++;
			fireSound.play()
			fireSound.setVolume(1)
			bullets.push(new bullet())
		}
	}
}

function windowResized() {
	s = min(windowWidth / 256, windowHeight / 192);
	resizeCanvas(256 * s, 192 * s);
}

function autoQuality() {
	if (frameRate() < 20 && frameCount > 20) {
		slowFrames += 1
	}
	if (slowFrames / frameCount > 0.2 && frameCount > 60) {
		quality = false;
	}
}

function input() {
	let vec = createVector(0, 0);
	if (keys[87] || keys[38]) {
		vec.y--;
	}
	if (keys[83] || keys[40]) {
		vec.y++;
	}
	if (keys[65] || keys[37]) {
		vec.x--;
	}
	if (keys[68] || keys[39]) {
		vec.x++;
	}
	return vec;
}