function drawGround(xo, yo) {
	push()
	imageMode(CORNER)
	a = 32 * s
	translate(xo % a, yo % a)
	for (var x = -1; x < 9; x++) {
		for (var y = -1; y < 7; y++) {
			let i = (floor(x) - floor(xo / a))
			let j = (floor(y) - floor(yo / a))
			if (xo < 0) {
				i--;
			}
			if (yo < 0) {
				j--;
			}
			let id = getLevel(i, j)
			if (id === 0) {
				image(grass, x * 32 * s, y * 32 * s, 32.1 * s, 32.1 * s);
			} else if (id == 1) {
				image(dirt, x * 32 * s, y * 32 * s, 32.1 * s, 32.1 * s);
			} else if (id == 2) {
				//nothing
			}
		}
	}
	pop()
}

function drawWalls(xo, yo) {
	push()
	shadowLayer.push()
	imageMode(CORNER);
	a = 32 * s
	translate(xo % a, yo % a)
	shadowLayer.translate((xo / s) % 32, (yo / s) % 32)
	shadowLayer.noStroke()
	shadowLayer.fill(0)
	for (var x = -1; x < 10; x++) {
		for (var y = -1; y < 8; y++) {
			let i = (floor(x) - floor(xo / a))
			let j = (floor(y) - floor(yo / a))
			if (xo < 0) {
				i--;
			}
			if (yo < 0) {
				j--;
			}
			let id = getLevel(i, j)
			if (id == 2) {
				if(noise(i / 2, j / 2) > 0.35) {
					image(wall, x * 32 * s - 8 * s, y * 32 * s - 8 * s, 40.1 * s, 40.1 * s);
				}else {
					image(mossyWall, x * 32 * s - 8 * s, y * 32 * s - 8 * s, 40.1 * s, 40.1 * s);
				}
				if (quality) {
					shadowLayer.rect(x * 32 + 1.5, y * 32 + 6, 32.1, 32.1);
				}
			}
		}
	}
	shadowLayer.pop()
	pop()
}

function drawGrassTop(xo, yo) {
	push()
	imageMode(CORNER)
	a = 32 * s
	translate(xo % a, yo % a)
	for (var x = -1; x < 9; x++) {
		for (var y = -1; y < 7; y++) {
			let i = (floor(x) - floor(xo / a))
			let j = (floor(y) - floor(yo / a))
			if (xo < 0) {
				i--;
			}
			if (yo < 0) {
				j--;
			}
			let drift = (noise(frameCount * 0.03, (x + xo / a) * 0.15, (y + xo / a) * 0.15) - 0.5) * s * 1.5
			let id = getLevel(i, j)
			if (id === 0) {
				image(grassTop, x * 32 * s + drift, y * 32 * s - (0.9 * s), 32 * s, 32 * s);
				image(grassTop, x * 32 * s + drift + drift + drift, y * 32 * s - (1.8 * s), 32 * s, 32 * s);
				image(grassTop, x * 32 * s + drift + drift + drift + drift + drift, y * 32 * s - (2.7 * s), 32 * s, 32 * s);
			}
		}
	}
	pop()
}

function drawTank(r) {
	push()
	imageMode(CENTER)
	translate(256 * s / 2, 192 * s / 2)
	rotate(r)
	image(tankAnm[floor(p.bodyAnm)], 0, 0, 40 * s, 40 * s)
	pop()
}

function drawTankHead(r) {
	push()
	imageMode(CENTER)
	translate(256 * s / 2, 192 * s / 2)
	rotate(r)
	image(tankHeadAnm[p.fireAnm], 0, 0, 40 * s, 40 * s)
	pop()
}

function bodyShadow() {
	shadowLayer.push()
	shadowLayer.noStroke()
	shadowLayer.fill(0)
	shadowLayer.translate(129, 100)
	shadowLayer.rotate(p.bodyVec.heading())
	shadowLayer.quad(-16, -12, 16, -12, 16, 12, -16, 12)
	shadowLayer.pop()
}

function headShadow() {
	shadowLayer.push()
	shadowLayer.noStroke()
	shadowLayer.fill(0)
	shadowLayer.translate(129, 100)
	shadowLayer.rotate(p.headVec.heading())
	shadowLayer.quad(0, -1, 18, -1, 18, 1, 0, 1)
	shadowLayer.pop()
}

function drawShadowsLayer() {
	shadowLayer.loadPixels()
	for (var i = 0; i < 256 * 196; i++) {
		shadowLayer.pixels[i * 4 + 3] *= 110 / 255
	}
	shadowLayer.updatePixels()
	image(shadowLayer, 0, 0, 256 * s, 192 * s);
	noTint();
	shadowLayer.clear();
}

function qualityIcon() {
	let icon;
	if (quality) {
		icon = lowIcon;
	} else {
		icon = highIcon;
	}
	image(icon, 255 * s - icon.width * s / 2, 191 * s - icon.height * s / 2, icon.width * s / 2, icon.height * s / 2);
}